#ifndef TREC_HELPER_FUNCTIONS_H

#define TREC_HELPER_FUNCTIONS_H

#include "trec_core_functions.h"

int get_count_tracking(TrackingEntry *entries, int entries_count);
char *convert_seconds_to_string(int seconds);
void check_name_length(char *name);

#endif