#ifndef TREC_CORE_FUNCTIONS_H

#define TREC_CORE_FUNCTIONS_H

#pragma pack(1)
typedef struct 
{
	int start_time;
	int end_time;
	int total_time_spent;
    int currently_tracking;
	char name[32];
} TrackingEntry;

extern int entry_size;

void print_help();
void start(char name[]);
void stop();
void cancel();
void info();
void report(char filter[]);
void delete_entry(char name[]);

#endif