#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "trec_core_functions.h"

int get_count_tracking(TrackingEntry *entries, int entries_count) //Returns the number of projects that are currently being tracked
{
	int count_tracking = 0;
	for(int i = 0; i < entries_count; i++)
	{
		if(entries[i].currently_tracking == 1)
		{
			count_tracking++;
		}
	}
	return count_tracking;
}

char *convert_seconds_to_string(int seconds) //Converts seconds to a string in the format "HH:MM:SS"
{
	int hours = floor(seconds / 3600);
	int minutes = floor((seconds - hours * 3600) / 60);
	seconds = seconds - hours * 3600 - minutes * 60;

	char *result = malloc(9 * sizeof(char) + 1);

	sprintf(result, "%02d:%02d:%02d", hours, minutes, seconds);

	return result;
}

void check_name_length(char *name) //Checks if the name is too long
{
	if(strlen(name) >= 32)
	{
		printf("Fehler: Der Name ist zu lang\n");
		exit(1);
	}
}