#ifndef TREC_FILE_HANDLING_H

#define TREC_FILE_HANDLING_H

#include "trec_core_functions.h"

//Global variables used to store the paths to the entries file and make it available to all relevant functions. Will be initialized at startup
extern char entries_file_path[500];
extern char entries_folder_path[500];

int get_entries_count_from_file();
TrackingEntry* get_entries();
void write_entries(TrackingEntry* entries, int entries_count);
void initialize_file_handling();

#endif