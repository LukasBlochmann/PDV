make
sudo make install
trec