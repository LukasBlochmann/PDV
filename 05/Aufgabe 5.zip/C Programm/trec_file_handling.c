#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <errno.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include "trec_core_functions.h"
#include "trec_file_handling.h"

//char entries_file_path[500] = "/mnt/c/Users/gerri/AppData/Roaming//trec//entries.bin";
//char entries_folder_path[500] = "/mnt/c/Users/gerri/AppData/Roaming/trec/";
char entries_file_path[500] = {'\0'};
char entries_folder_path[500] = {'\0'};

int get_entries_count_from_file() //Returns the number of entries in the entries file
{
    FILE *entries_file = fopen(entries_file_path, "rb");
	fseek(entries_file, 0, SEEK_END);
	int entries_count = ftell(entries_file) / entry_size;
	fclose(entries_file);

	return entries_count;
}

//Required: free(entries) by caller
TrackingEntry *get_entries() //Returns a pointer to an array of the current TrackingEntries
{
	int entries_count = get_entries_count_from_file();
	TrackingEntry *entries = malloc(entries_count * entry_size);

	FILE *entries_file = fopen(entries_file_path, "rb");
	fread(entries, entry_size, entries_count, entries_file);
	fclose(entries_file);

	return entries;

}

void write_entries(TrackingEntry *entries, int entries_count) //Writes the entries to the entries file and frees the memory of the entries array
{
	FILE *entries_file = fopen(entries_file_path, "wb");
	fwrite(entries, entry_size, entries_count, entries_file);
	fclose(entries_file);
	free(entries);
}

void initialize_file_handling()
{
	#ifdef _WIN32 //Windows operating system
		char *appdata = getenv("APPDATA");
		strcpy(entries_folder_path, appdata);
		strcat(entries_folder_path, "\\trec\\");

		strcpy(entries_file_path, entries_folder_path);
		strcat(entries_file_path, "entries.bin");
	#endif
	#ifdef __linux__ //Linux operating system
		char *home = getenv("HOME");
		strcpy(entries_folder_path, home);
		strcat(entries_folder_path, "/.trec/");

		strcpy(entries_file_path, entries_folder_path);
		strcat(entries_file_path, "entries.bin");
	#endif

	DIR *dir = opendir(entries_folder_path);
	if (dir) //Directory exists
	{
		closedir(dir);
	}
	else if (ENOENT == errno) //Directory does not exist
	{
		mkdir(entries_folder_path, 0700);
	}

	if(access(entries_file_path, F_OK) == -1) //File does not exist
	{
		FILE *entries_file = fopen(entries_file_path, "wb");
		fclose(entries_file);
	}

	//At this point, the file and the directory do exist and were created if they did not exist before. As this is always executed at the beginning of the program, further checks are not necessary.
}