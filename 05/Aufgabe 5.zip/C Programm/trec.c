
#include <stdio.h>
#include <string.h>
#include "trec_core_functions.h"
#include "trec_file_handling.h"
#include "trec_helper_functions.h"

int main(int argc, char *argv[])
{
	initialize_file_handling(); //Initialize the working environment

	if (argc <= 1) //No arguments were passed
	{
		print_help();
		return 1;
	}
	
	if (strcmp(argv[1], "start") == 0) //Starts a new time tracking
	{
		if (argc <= 2) //No project name was passed
		{
			printf("Fehler: Bitte geben Sie an, wie das Projekt heißen soll, das Sie erstellen wollen\n");
			return 1;
		}
		check_name_length(argv[2]);
		start(argv[2]);
		return 0;
	}
	else if (strcmp(argv[1], "stop") == 0) //Stops the current time tracking
	{
		stop();
		return 0;
	}
	else if (strcmp(argv[1], "cancel") == 0) //Cancels the current time tracking
	{
		cancel();
		return 0;
	}
	else if (strcmp(argv[1], "info") == 0) //Prints information about the current time tracking
	{
		info();
		return 0;
	}
	else if (strcmp(argv[1], "report") == 0) //Prints a report about the current state of all (or only filtered) time tracking entries
	{
		if (argc == 2)
		{
			char temp[1] = {'\0'}; //If no filter was passed, the filter is set to an empty string
			report(temp);
			return 0;
		}
		check_name_length(argv[2]);
		report(argv[2]);
		return 0;
	}
	else if (strcmp(argv[1], "delete") == 0) //Deletes the time tracking entry with the given name
	{
		if (argc <= 2)
		{
			printf("Fehler: Bitte geben Sie den Projektnamen an, den Sie löschen wollen\n");
			return 1;
		}
		check_name_length(argv[2]);
		delete_entry(argv[2]);
		return 0;
	}
	else
	{
		printf("Unbekannter Befehl\n\nHilfe zur Bedienung: \n");
		print_help();
		return 1;
	}
}