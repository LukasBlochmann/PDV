#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include "trec_core_functions.h"
#include "trec_file_handling.h"
#include "trec_helper_functions.h"

int entry_size = sizeof(TrackingEntry); //Size of a single TrackingEntry element

void print_help()
{
	printf("Time Recorder\n");
	printf("Benutzung: \n");
	printf("./trec <Befehl>\n\n");
	printf("Die Befehle sind:\n");
	printf("start <Projektnahme> :  Startet eine neue Zeiterfassung für das angegebene Projekt. Der Name darf nicht länger als 32 Zeichen sein\n");
	printf("stop                 :  Beendet die Zeiterfassung für das aktuelle Projekt\n");
	printf("cancel               :  Bricht die Zeiterfassung für das aktuelle Projekt ab ohne zu speichern\n");
	printf("info                 :  Zeigt an, für welches Projekt gerade Zeit erfasst wird\n");
	printf("report [Filter]      :  Zeigt alle Projekte mit dr Summe der bisher erfassten Zeit an. Wenn ein Filter angegeben wird, werden nur Projekte mit diesem Namen angezeigt\n");
	printf("delete <Projektnahme>:  Löscht das Projekt mit dem angegebenen Namen \n\n");
}

void start(char name[]) //Starts the time tracking for a project
{
	TrackingEntry *entries = get_entries();
	int entries_count = get_entries_count_from_file();

	if(get_count_tracking(entries, entries_count) > 0) //There is already a project being tracked, no new project can be started
	{
		printf("Fehler: Es wird bereits ein Projekt erfasst, eine erneute Erfassung ist daher aktuell nicht möglich\n");
		free(entries); //Manual free, because the write_entries function is not called
		exit(2);
	}

	for(int i = 0; i < entries_count; i++)
	{
		if(strcmp(entries[i].name, name) == 0) //Project already exists => start tracking
		{
			entries[i].currently_tracking = 1;
			entries[i].start_time = (int)time(NULL);
			entries[i].end_time = 0;
			write_entries(entries, entries_count);
			printf("Zeiterfassung gestartet für \"%s\"\n", name);
			return;
		}
	}

	//Project does not exist yet
	TrackingEntry new_entry; //Creating and initializing new entry
	new_entry.currently_tracking = 1;
	new_entry.start_time = (int)time(NULL);
	new_entry.end_time = 0;
	new_entry.total_time_spent = 0;
	strcpy(new_entry.name, name);

	entries_count++;
	entries = realloc(entries, entries_count * entry_size); //Allocate memory for the new entry
	entries[entries_count - 1] = new_entry;

	write_entries(entries, entries_count);
	printf("Zeiterfassung gestartet für \"%s\"\n", name);
	return;
}

void stop() //Stops the time tracking for the current project
{
	TrackingEntry *entries = get_entries();
	int entries_count = get_entries_count_from_file();

	if(get_count_tracking(entries, entries_count) == 0)
	{
		printf("Es läuft derzeit keine Zeiterfassung\n");
		free(entries);
		exit(2);
	}

	for(int i = 0; i < entries_count; i++)
	{
		if(entries[i].currently_tracking == 1)
		{
			entries[i].currently_tracking = 0;
			entries[i].end_time = (int)time(NULL);
			entries[i].total_time_spent += entries[i].end_time - entries[i].start_time;
			printf("Zeiterfassung gestoppt für \"%s\"\n", entries[i].name);
			char *time_string = convert_seconds_to_string(entries[i].total_time_spent);
			printf("Zeit bisher: %s\n", time_string);
			write_entries(entries, entries_count);
			free(time_string);
			return;
		}
	}
}

void cancel() //Cancels the time tracking for the current project
{
	TrackingEntry *entries = get_entries();
	int entries_count = get_entries_count_from_file();

	if(get_count_tracking(entries, entries_count) == 0)
	{
		printf("Fehler: Es läuft derzeit keine Zeiterfassung\n");
		free(entries); //Manual free, because the write_entries function is not called
		exit(2);
	}

	for(int i = 0; i < entries_count; i++)
	{
		if(entries[i].currently_tracking == 1)
		{
			entries[i].currently_tracking = 0;
			write_entries(entries, entries_count);
			printf("Zeiterfassung abgebrochen für \"%s\"\n", entries[i].name);
			return;
		}
	}
}

void info() //Prints information about the current time tracking
{
	TrackingEntry *entries = get_entries();
	int entries_count = get_entries_count_from_file();

	if(entries_count == 0)
	{
		printf("Es läuft derzeit keine Zeiterfassung\n");
		free(entries); //Manual free, because the write_entries function is not called
		exit(2);
	}

	for(int i = 0; i < entries_count; i++)
	{
		if(entries[i].currently_tracking == 1)
		{
			printf("Zeiterfassung läuft für \"%s\"\n", entries[i].name);
			char *time_string = convert_seconds_to_string(entries[i].total_time_spent + (int)time(NULL) - entries[i].start_time);
			printf("Zeit bisher: %s\n", time_string);
			free(entries); //Manual free, because the write_entries function is not called
			free(time_string);
			return;
		}
	}

	printf("Es läuft gerade keine Zeiterfassung\n");
}

void report(char filter[]) //Prints a report of the time tracking
{
	TrackingEntry *entries = get_entries();
	int entries_count = get_entries_count_from_file();

	int total_time_spent = 0; //Total time spent on all projects
	for(int i = 0; i < entries_count; i++)
	{
		if(entries[i].currently_tracking == 0) //If the project is currently not being tracked, just add its total time to the total time spent
		{
			total_time_spent += entries[i].total_time_spent;
		}
		else
		{
			total_time_spent += entries[i].total_time_spent + (int)time(NULL) - entries[i].start_time; //If the project is currently being tracked, add its current time to the total time spent
		}
	}
	
	int current_time = 0;
	for(int i = 0; i < entries_count; i++)
	{
		if(filter[0] != '\0') //Do the filtering only if a filter was passed
		{
			if(strstr(entries[i].name, filter) == NULL) //Filter comparison
			{
				continue;
			}
		}
		if(entries[i].currently_tracking == 0)
		{
			current_time = entries[i].total_time_spent;
		}
		else
		{
			current_time = entries[i].total_time_spent + (int)time(NULL) - entries[i].start_time;
		}
		char *time_string = convert_seconds_to_string(current_time);
		printf("%-33s: %s ( %d%%)\n", entries[i].name, time_string, (int)((float)current_time / (float)total_time_spent * 100));
		free(time_string);
	}

	free(entries); 
}

void delete_entry(char name[]) //Deletes a project
{
	TrackingEntry *entries = get_entries();
	int entries_count = get_entries_count_from_file();

	if(entries_count == 0)
	{
		printf("Es gibt keine Projekte, die gelöscht werden könnten\n");
		free(entries); 
		exit(2);
	}

	int project_found = 0;
	for(int i = 0; i < entries_count; i++)
	{
		if(strcmp(entries[i].name, name) == 0) //Project found
		{
			project_found = 1;
			break;
		}
	}
	if(project_found == 0) //Project not found
	{
		printf("Es gibt kein Projekt mit dem Namen \"%s\"\n", name);
		free(entries); 
		return;
	}

	entries_count -= 1;
	TrackingEntry *new_entries = malloc(entries_count * sizeof(TrackingEntry)); //Allocate memory for the new entries array (one entry less than before)
	
	for(int i = 0; i < entries_count; i++)
	{
		if(strcmp(entries[i].name, name) == 0) //Project found => don't copy it to the new array
		{
			continue;
		}
		new_entries[i] = entries[i];
	}

	printf("Projekt \"%s\" erfolgreich gelöscht\n", name);
	write_entries(new_entries, entries_count);
}